"use client";

import { ChangeEvent, DragEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";

type VisualMode = "particles" | "waves" | "glass" | "terrain" | "forms";
type Harmony =
  | "analogous"
  | "complementary"
  | "split"
  | "triadic"
  | "tetradic"
  | "square"
  | "monochrome"
  | "warm"
  | "cool"
  | "pastel"
  | "neon"
  | "earth"
  | "ocean";
type Row = Record<string, string>;

const BUILT_IN_DATASETS = [
  {
    name: "Collective Mood",
    fileName: "collective-mood.csv",
    csv: `hour,calm,tension,joy,focus
06:00,82,18,34,71
08:00,61,48,52,88
10:00,54,62,64,93
12:00,68,51,79,76
14:00,47,74,58,69
16:00,52,68,72,81
18:00,76,39,88,62
20:00,89,21,73,47
22:00,94,12,55,36`,
  },
  {
    name: "Urban Rhythm",
    fileName: "urban-rhythm.csv",
    csv: `district,movement,noise,green,connection
North,86,72,34,61
Harbour,58,64,42,79
Old Town,43,51,28,92
West,74,83,55,66
Central,97,94,18,88
Gardens,39,27,96,73
East,81,76,47,58
Riverside,62,48,78,84
South,69,71,51,64
Hills,31,22,89,49`,
  },
  {
    name: "Ocean Conditions",
    fileName: "ocean-conditions.csv",
    csv: `day,tide,temperature,salinity,light
01,24,61,82,36
02,38,64,79,49
03,71,66,77,68
04,92,68,74,83
05,76,69,73,91
06,44,67,76,72
07,19,64,81,51
08,33,62,84,39
09,68,63,80,57
10,88,65,78,76
11,73,67,75,87
12,41,66,79,63`,
  },
  {
    name: "Seasonal Growth",
    fileName: "seasonal-growth.csv",
    csv: `week,growth,rain,sunlight,pollination
01,12,84,31,18
02,18,76,42,25
03,29,68,51,39
04,43,57,64,58
05,62,49,77,74
06,78,36,89,92
07,91,28,96,88
08,84,42,82,79
09,69,58,71,66
10,53,72,59,48
11,38,81,46,31
12,22,89,34,20`,
  },
  {
    name: "Cosmic Weather",
    fileName: "cosmic-weather.csv",
    csv: `cycle,magnetism,radiation,density,velocity
A1,36,72,18,89
A2,58,64,29,76
A3,43,83,42,68
A4,78,56,61,92
A5,67,91,54,81
A6,92,76,88,64
A7,74,69,96,73
A8,86,88,72,95
A9,61,79,65,82
A10,49,93,41,71
A11,72,84,59,87
A12,88,96,78,98`,
  },
] as const;

const DEMO_CSV = BUILT_IN_DATASETS[0].csv;

const MODES: { id: VisualMode; name: string; note: string }[] = [
  { id: "particles", name: "Particles", note: "Points become a living field" },
  { id: "waves", name: "Waves", note: "Rhythm traced as flowing lines" },
  { id: "glass", name: "Glass", note: "Values refract into luminous forms" },
  { id: "terrain", name: "Terrain", note: "Data rises into an inner landscape" },
  { id: "forms", name: "Forms", note: "Soft bodies reveal relationships" },
];

const HARMONIES: Harmony[] = [
  "analogous", "complementary", "split", "triadic", "tetradic", "square",
  "monochrome", "warm", "cool", "pastel", "neon", "earth", "ocean",
];
const ATMOSPHERES = ["density", "energy", "flow"] as const;
type Atmosphere = typeof ATMOSPHERES[number];

const clamp = (n: number, min = 0, max = 1) => Math.max(min, Math.min(max, n));
const randomOther = <T,>(items: T[], current: T) => {
  const choices = items.filter((item) => item !== current);
  return choices[Math.floor(Math.random() * choices.length)] ?? current;
};
const hash = (text: string) => {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return () => ((h = Math.imul(h ^ (h >>> 15), 2246822519)) >>> 0) / 4294967296;
};

function parseCSV(text: string) {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (!lines.length) return { headers: [] as string[], rows: [] as Row[] };
  const split = (line: string) => {
    const result: string[] = [];
    let current = "";
    let quoted = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') quoted = !quoted;
      else if (char === "," && !quoted) {
        result.push(current.trim());
        current = "";
      } else current += char;
    }
    result.push(current.trim());
    return result;
  };
  const headers = split(lines[0]);
  const rows = lines.slice(1).map((line) => {
    const values = split(line);
    return headers.reduce<Row>((row, header, index) => {
      row[header] = values[index] ?? "";
      return row;
    }, {});
  });
  return { headers, rows };
}

function hexToHsl(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0;
  const l = (max + min) / 2;
  const d = max - min;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  if (d) {
    if (max === r) h = 60 * (((g - b) / d) % 6);
    else if (max === g) h = 60 * ((b - r) / d + 2);
    else h = 60 * ((r - g) / d + 4);
  }
  return [(h + 360) % 360, s * 100, l * 100];
}

function hsl(h: number, s: number, l: number, a = 1) {
  return `hsla(${(h + 360) % 360} ${s}% ${l}% / ${a})`;
}

function paletteFrom(base: string, harmony: Harmony) {
  const [h, s, l] = hexToHsl(base);
  if (harmony === "earth") return ["#3f4938", "#8e6243", "#c49a62", "#d9cfaa"];
  if (harmony === "ocean") return ["#061b2c", "#075985", "#24a9a2", "#b8eee3"];

  const offsets: Record<Exclude<Harmony, "earth" | "ocean">, number[]> = {
    analogous: [-32, 0, 28, 62],
    complementary: [0, 180, 24, 204],
    split: [0, 150, 210, 30],
    triadic: [0, 120, 240, 48],
    tetradic: [0, 60, 180, 240],
    square: [0, 90, 180, 270],
    monochrome: [0, 0, 0, 0],
    warm: [-34, -8, 20, 46],
    cool: [-18, 18, 56, 104],
    pastel: [-28, 0, 32, 68],
    neon: [0, 112, 224, 292],
  };
  return offsets[harmony].map((offset, index) =>
    hsl(
      h + offset,
      harmony === "pastel" ? 62 : harmony === "neon" ? 100 : Math.min(96, s + (index % 2 ? 10 : -4)),
      harmony === "pastel" ? 72 + index * 4 : harmony === "neon" ? 56 + index * 4 : clamp(l + (harmony === "monochrome" ? index * 13 - 14 : index * 3), 22, 82)
    )
  );
}

function numericValues(rows: Row[], key: string) {
  const values = rows.map((row) => Number(row[key])).filter(Number.isFinite);
  if (!values.length) return [0.25, 0.6, 0.45, 0.82];
  const min = Math.min(...values), max = Math.max(...values);
  return values.map((value) => max === min ? 0.5 : (value - min) / (max - min));
}

function drawArtwork(
  canvas: HTMLCanvasElement,
  values: number[],
  mode: VisualMode,
  colors: string[],
  density: number,
  energy: number,
  flow: number,
  seed: number,
  time: number
) {
  const width = canvas.width;
  const height = canvas.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const unit = Math.max(0.7, Math.min(1.35, width / 900));
  const rand = hash(`${seed}-${values.length}-${values.join("-")}`);
  const visualDensity = clamp(Math.pow(density, 0.72) * 1.08);
  const visualEnergy = energy * 1.45;
  const visualFlow = flow * 1.4;
  const t = time * (0.00012 + visualFlow * 0.00028);

  ctx.clearRect(0, 0, width, height);
  const bg = ctx.createRadialGradient(width * 0.5, height * 0.44, 0, width * 0.5, height * 0.5, width * 0.8);
  bg.addColorStop(0, "#171520");
  bg.addColorStop(0.52, "#0c0c10");
  bg.addColorStop(1, "#050507");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  ctx.globalCompositeOperation = "screen";

  if (mode === "particles") {
    const count = Math.floor(100 + visualDensity * 430);
    for (let i = 0; i < count; i++) {
      const value = values[i % values.length];
      const angle = rand() * Math.PI * 2 + t * (i % 3 ? 1 : -1);
      const radius = (0.08 + rand() * 0.36 + value * 0.12) * Math.min(width, height);
      const curl = Math.sin(angle * 3 + value * 8 + t * 4) * 78 * visualEnergy;
      const x = width * 0.5 + Math.cos(angle) * radius + Math.cos(angle * 4) * curl;
      const y = height * 0.5 + Math.sin(angle) * radius * 0.68 + Math.sin(angle * 3) * curl;
      const size = 0.45 + value * 2.8 + rand() * 1.7;
      ctx.beginPath();
      ctx.fillStyle = colors[i % colors.length].replace(" / 1)", ` / ${0.18 + value * 0.68})`);
      ctx.arc(x, y, size * unit, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  if (mode === "waves") {
    const lines = Math.floor(18 + visualDensity * 54);
    ctx.lineWidth = Math.max(0.6, unit * 0.72);
    for (let line = 0; line < lines; line++) {
      const value = values[line % values.length];
      const yBase = height * (0.15 + (line / lines) * 0.7);
      ctx.beginPath();
      for (let x = -20; x <= width + 20; x += 5) {
        const phase = x / width * Math.PI * (3 + visualFlow * 9);
        const swell = Math.sin(phase + line * 0.13 + t * 5) * (12 + value * 82 * visualEnergy);
        const second = Math.sin(phase * 0.43 - t * 2) * 24 * value;
        const y = yBase + swell + second;
        if (x === -20) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = colors[line % colors.length].replace(" / 1)", ` / ${0.12 + value * 0.45})`);
      ctx.stroke();
    }
  }

  if (mode === "glass") {
    const count = Math.floor(4 + visualDensity * 11);
    ctx.filter = `blur(${Math.max(0.2, 1.2 * unit)}px)`;
    for (let i = 0; i < count; i++) {
      const value = values[i % values.length];
      const x = width * (0.16 + rand() * 0.68);
      const y = height * (0.13 + rand() * 0.72);
      const r = (32 + value * 108 + rand() * 60) * unit;
      const grad = ctx.createRadialGradient(x - r * 0.3, y - r * 0.38, r * 0.02, x, y, r);
      grad.addColorStop(0, "rgba(255,255,255,.9)");
      grad.addColorStop(0.12, colors[i % colors.length].replace(" / 1)", " / .55)"));
      grad.addColorStop(0.66, colors[(i + 1) % colors.length].replace(" / 1)", " / .1)"));
      grad.addColorStop(1, "rgba(255,255,255,.015)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.ellipse(x, y, r * (0.65 + value * 0.5), r, t + i * 0.7, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,.26)";
      ctx.lineWidth = 0.8 * unit;
      ctx.stroke();
    }
    ctx.filter = "none";
  }

  if (mode === "terrain") {
    const layers = Math.floor(10 + visualDensity * 27);
    for (let layer = layers; layer >= 0; layer--) {
      const depth = layer / layers;
      ctx.beginPath();
      ctx.moveTo(-10, height + 10);
      for (let x = -10; x <= width + 10; x += 7) {
        const index = Math.floor((x / width) * values.length * 2 + layer) % values.length;
        const value = values[Math.abs(index)] ?? 0.5;
        const ridge = Math.sin(x * 0.011 + layer * 0.33 + t * 2) * 18;
        const mountain = Math.sin(x * 0.004 + layer * 0.18) * 92 * value * visualEnergy;
        const y = height * (0.36 + depth * 0.58) - mountain - ridge;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(width + 10, height + 10);
      ctx.closePath();
      ctx.fillStyle = colors[layer % colors.length].replace(" / 1)", ` / ${0.025 + (1 - depth) * 0.12})`);
      ctx.fill();
      ctx.strokeStyle = colors[layer % colors.length].replace(" / 1)", ` / ${0.08 + (1 - depth) * 0.22})`);
      ctx.lineWidth = 0.6 * unit;
      ctx.stroke();
    }
  }

  if (mode === "forms") {
    const count = Math.floor(6 + visualDensity * 18);
    ctx.filter = `blur(${3.5 * unit}px)`;
    for (let i = 0; i < count; i++) {
      const value = values[i % values.length];
      const x = width * (0.12 + rand() * 0.76);
      const y = height * (0.12 + rand() * 0.76);
      const r = (24 + value * 100 + rand() * 30) * unit;
      ctx.beginPath();
      const points = 18;
      for (let p = 0; p <= points; p++) {
        const angle = p / points * Math.PI * 2;
        const wobble = 1 + Math.sin(angle * 3 + i + t * 4) * 0.31 * visualEnergy;
        const px = x + Math.cos(angle) * r * wobble;
        const py = y + Math.sin(angle) * r * (0.55 + value * 0.55) * wobble;
        if (!p) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fillStyle = colors[i % colors.length].replace(" / 1)", ` / ${0.12 + value * 0.35})`);
      ctx.fill();
    }
    ctx.filter = "none";
  }

  const vignette = ctx.createRadialGradient(width / 2, height / 2, width * 0.2, width / 2, height / 2, width * 0.72);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(0,0,0,.62)");
  ctx.globalCompositeOperation = "source-over";
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);
}

export default function Home() {
  const initial = useMemo(() => parseCSV(DEMO_CSV), []);
  const [rows, setRows] = useState<Row[]>(initial.rows);
  const [headers, setHeaders] = useState(initial.headers);
  const [dataText, setDataText] = useState(DEMO_CSV);
  const [dataMode, setDataMode] = useState<"upload" | "paste">("upload");
  const [visualMode, setVisualMode] = useState<VisualMode>("particles");
  const [measure, setMeasure] = useState("energy");
  const [baseColor, setBaseColor] = useState("#d95cff");
  const [harmony, setHarmony] = useState<Harmony>("analogous");
  const [density, setDensity] = useState(58);
  const [energy, setEnergy] = useState(72);
  const [flow, setFlow] = useState(46);
  const [seed, setSeed] = useState(9);
  const [fileName, setFileName] = useState(BUILT_IN_DATASETS[0].fileName);
  const [datasetIndex, setDatasetIndex] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [showData, setShowData] = useState(false);
  const [motionEnabled, setMotionEnabled] = useState(true);
  const [atmosphereTarget, setAtmosphereTarget] = useState<Atmosphere>("density");
  const [controlMessage, setControlMessage] = useState("");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const controlTimerRef = useRef<number | null>(null);
  const lastWheelRef = useRef(0);
  const smoothAtmosphereRef = useRef({ density: 58, energy: 72, flow: 46 });
  const colors = useMemo(() => paletteFrom(baseColor, harmony), [baseColor, harmony]);
  const values = useMemo(() => numericValues(rows, measure), [rows, measure]);

  const notifyControl = useCallback((message: string) => {
    setControlMessage(message);
    if (controlTimerRef.current) window.clearTimeout(controlTimerRef.current);
    controlTimerRef.current = window.setTimeout(() => setControlMessage(""), 1500);
  }, []);

  const updateData = useCallback((text: string, name = "pasted-data.csv") => {
    const parsed = parseCSV(text);
    if (!parsed.headers.length || !parsed.rows.length) return;
    setDataText(text);
    setHeaders(parsed.headers);
    setRows(parsed.rows);
    setFileName(name);
    setDatasetIndex(-1);
    const numeric = parsed.headers.find((header) => parsed.rows.some((row) => Number.isFinite(Number(row[header]))));
    if (numeric) setMeasure(numeric);
  }, []);

  const loadBuiltInDataset = useCallback((index: number, announce = true) => {
    const dataset = BUILT_IN_DATASETS[index];
    if (!dataset) return;
    const parsed = parseCSV(dataset.csv);
    setDataText(dataset.csv);
    setHeaders(parsed.headers);
    setRows(parsed.rows);
    setFileName(dataset.fileName);
    setDatasetIndex(index);
    const numeric = parsed.headers.find((header) => parsed.rows.some((row) => Number.isFinite(Number(row[header]))));
    if (numeric) setMeasure(numeric);
    setSeed((value) => value + 1);
    if (announce) notifyControl(`Q · ${dataset.name}`);
  }, [notifyControl]);

  const onFile = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => updateData(String(reader.result ?? ""), file.name);
    reader.readAsText(file);
  };

  const onDrop = (event: DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    setDragging(false);
    onFile(event.dataTransfer.files[0]);
  };

  const remixDataset = useCallback(() => {
    const choices = BUILT_IN_DATASETS.map((_, index) => index).filter((index) => index !== datasetIndex);
    const nextIndex = choices[Math.floor(Math.random() * choices.length)] ?? 0;
    loadBuiltInDataset(nextIndex);
  }, [datasetIndex, loadBuiltInDataset]);

  const randomizeVisual = useCallback(() => {
    setVisualMode((current) => {
      const next = randomOther(MODES.map((mode) => mode.id), current);
      notifyControl(`W · ${MODES.find((mode) => mode.id === next)?.name ?? next}`);
      return next;
    });
    setSeed((value) => value + 1);
  }, [notifyControl]);

  const randomizeHarmony = useCallback(() => {
    setHarmony((current) => {
      const next = randomOther(HARMONIES, current);
      notifyControl(`E · ${next.replace("-", " ")} harmony`);
      return next;
    });
  }, [notifyControl]);

  const selectNextAtmosphere = useCallback(() => {
    setAtmosphereTarget((current) => {
      const next = ATMOSPHERES[(ATMOSPHERES.indexOf(current) + 1) % ATMOSPHERES.length];
      notifyControl(`R · Knob controls ${next}`);
      return next;
    });
  }, [notifyControl]);

  const turnAtmosphereKnob = useCallback((direction: -1 | 1) => {
    const adjust = (value: number) => clamp(value + direction * 10, 5, 100);
    if (atmosphereTarget === "density") setDensity((value) => adjust(value));
    if (atmosphereTarget === "energy") setEnergy((value) => adjust(value));
    if (atmosphereTarget === "flow") setFlow((value) => adjust(value));
    notifyControl(`${direction > 0 ? "↻" : "↺"} · ${atmosphereTarget} ${direction > 0 ? "+10%" : "−10%"}`);
  }, [atmosphereTarget, notifyControl]);

  useEffect(() => {
    const handleKeyboard = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.matches("input, textarea, select")) return;
      const key = event.key.toLowerCase();
      if (!["q", "w", "e", "a", "r", "arrowleft", "arrowright"].includes(key)) return;
      event.preventDefault();
      if (event.repeat && !["a", "arrowleft", "arrowright"].includes(key)) return;
      if (key === "q") remixDataset();
      if (key === "w") randomizeVisual();
      if (key === "e") randomizeHarmony();
      if (key === "a" || key === "arrowright") turnAtmosphereKnob(1);
      if (key === "arrowleft") turnAtmosphereKnob(-1);
      if (key === "r") selectNextAtmosphere();
    };

    const handleWheel = (event: WheelEvent) => {
      const now = performance.now();
      if (now - lastWheelRef.current < 55) {
        event.preventDefault();
        return;
      }
      const horizontal = Math.abs(event.deltaX) > Math.abs(event.deltaY);
      const delta = horizontal ? event.deltaX : -event.deltaY;
      if (delta === 0) return;
      event.preventDefault();
      lastWheelRef.current = now;
      turnAtmosphereKnob(delta > 0 ? 1 : -1);
    };

    window.addEventListener("keydown", handleKeyboard);
    window.addEventListener("wheel", handleWheel, { passive: false });
    return () => {
      window.removeEventListener("keydown", handleKeyboard);
      window.removeEventListener("wheel", handleWheel);
    };
  }, [remixDataset, randomizeVisual, randomizeHarmony, turnAtmosphereKnob, selectNextAtmosphere]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let visible = true;
    let lastTime = 0;
    const frameInterval = 1000 / 20;

    const resize = () => {
      const width = Math.min(1200, Math.max(420, Math.floor(canvas.clientWidth)));
      const height = Math.min(900, Math.max(420, Math.floor(canvas.clientHeight)));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      const smooth = smoothAtmosphereRef.current;
      drawArtwork(canvas, values, visualMode, colors, smooth.density / 100, smooth.energy / 100, smooth.flow / 100, seed, lastTime);
    };

    const render = () => {
      if (!visible || document.visibilityState !== "visible") return;
      const smooth = smoothAtmosphereRef.current;
      const targets = { density, energy, flow };
      let transitioning = false;
      for (const key of ATMOSPHERES) {
        const distance = targets[key] - smooth[key];
        if (Math.abs(distance) > 0.08) {
          smooth[key] += distance * 0.12;
          transitioning = true;
        } else {
          smooth[key] = targets[key];
        }
      }
      if (!motionEnabled && !transitioning) return;
      lastTime = motionEnabled ? performance.now() : 0;
      drawArtwork(canvas, values, visualMode, colors, smooth.density / 100, smooth.energy / 100, smooth.flow / 100, seed, lastTime);
    };

    const resizeObserver = new ResizeObserver(resize);
    const visibilityObserver = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) render();
    }, { rootMargin: "80px" });
    resizeObserver.observe(canvas);
    visibilityObserver.observe(canvas);
    resize();
    const timer = window.setInterval(render, frameInterval);

    return () => {
      window.clearInterval(timer);
      resizeObserver.disconnect();
      visibilityObserver.disconnect();
    };
  }, [values, visualMode, colors, density, energy, flow, seed, motionEnabled]);

  const exportImage = () => {
    const source = canvasRef.current;
    if (!source) return;
    const exportCanvas = document.createElement("canvas");
    exportCanvas.width = 1600;
    exportCanvas.height = 1200;
    drawArtwork(exportCanvas, values, visualMode, colors, density / 100, energy / 100, flow / 100, seed, 0);
    const link = document.createElement("a");
    link.download = `aura-${visualMode}-${seed}.png`;
    link.href = exportCanvas.toDataURL("image/png");
    link.click();
  };

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#" aria-label="Aura home">AURA<span>°</span></a>
        <div className="top-center">DATA / EMOTION / FORM</div>
        <div className="top-actions">
          <span className="saved"><i /> Saved locally</span>
          <button className="export-button" onClick={exportImage}>Export artwork <span>↗</span></button>
        </div>
      </header>

      <section className="workspace">
        <aside className="panel left-panel">
          <div className="panel-heading">
            <span>01</span>
            <div><b>DATA SOURCE</b><small>Bring in your raw material</small></div>
          </div>
          <div className="segmented">
            <button className={dataMode === "upload" ? "active" : ""} onClick={() => setDataMode("upload")}>Upload CSV</button>
            <button className={dataMode === "paste" ? "active" : ""} onClick={() => setDataMode("paste")}>Paste data</button>
          </div>

          {dataMode === "upload" ? (
            <label
              className={`drop-zone ${dragging ? "dragging" : ""}`}
              onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
            >
              <input type="file" accept=".csv,text/csv" onChange={(event: ChangeEvent<HTMLInputElement>) => onFile(event.target.files?.[0])} />
              <span className="upload-mark">＋</span>
              <b>Drop your dataset here</b>
              <small>or click to choose a CSV</small>
            </label>
          ) : (
            <div className="paste-box">
              <textarea value={dataText} onChange={(event) => setDataText(event.target.value)} aria-label="Paste CSV data" />
              <button onClick={() => updateData(dataText)}>Use this data</button>
            </div>
          )}

          <div className="file-card">
            <span className="file-icon">CSV</span>
            <div><b>{fileName}</b><small>{rows.length} rows · {headers.length} dimensions</small></div>
            <span className="file-ok">✓</span>
          </div>

          <div className="dataset-library">
            <label htmlFor="built-in-dataset">Built-in collection · 5 datasets</label>
            <select
              id="built-in-dataset"
              value={datasetIndex >= 0 ? datasetIndex : ""}
              onChange={(event) => loadBuiltInDataset(Number(event.target.value), false)}
            >
              {datasetIndex < 0 && <option value="">External data</option>}
              {BUILT_IN_DATASETS.map((dataset, index) => (
                <option key={dataset.fileName} value={index}>{String(index + 1).padStart(2, "0")} · {dataset.name}</option>
              ))}
            </select>
          </div>

          <button className="data-preview-toggle" onClick={() => setShowData((value) => !value)}>
            {showData ? "Hide" : "Inspect"} data <span>{showData ? "−" : "+"}</span>
          </button>
          {showData && (
            <div className="mini-table">
              <div>{headers.slice(0, 3).map((header) => <b key={header}>{header}</b>)}</div>
              {rows.slice(0, 4).map((row, index) => (
                <div key={index}>{headers.slice(0, 3).map((header) => <span key={header}>{row[header]}</span>)}</div>
              ))}
            </div>
          )}

          <div className="section-rule" />
          <div className="panel-heading compact">
            <span>02</span>
            <div><b>DATA MAPPING</b><small>Choose what shapes the artwork</small></div>
          </div>
          <label className="field-label">Primary measure</label>
          <select value={measure} onChange={(event) => setMeasure(event.target.value)}>
            {headers.map((header) => <option key={header} value={header}>{header}</option>)}
          </select>
          <div className="mapping-note"><i /><span><b>Value → scale & movement</b>Higher values create larger, faster forms.</span></div>
        </aside>

        <section className="canvas-shell">
          <canvas ref={canvasRef} aria-label={`Animated ${visualMode} artwork generated from ${fileName}`} />
          <div className={`control-toast ${controlMessage ? "visible" : ""}`} aria-live="polite">{controlMessage}</div>
          <div className="canvas-meta">
            <div>
              <span>GENERATIVE STUDY / {String(seed).padStart(2, "0")}</span>
              <h1>{visualMode === "terrain" ? "Inner topographies" : visualMode === "waves" ? "The shape of rhythm" : visualMode === "glass" ? "Transparent relations" : visualMode === "forms" ? "Bodies in relation" : "A field of feeling"}</h1>
            </div>
            <p>{rows.length} observations translated through <b>{measure}</b></p>
          </div>
          <div className="canvas-tools">
            <button className="regenerate" onClick={() => setSeed((value) => value + 1)}><span>↻</span> New composition</button>
            <button className="motion-toggle" onClick={() => setMotionEnabled((value) => !value)}><span>{motionEnabled ? "Ⅱ" : "▶"}</span> {motionEnabled ? "Pause motion" : "Play motion"}</button>
          </div>
          <div className="keyboard-hud">
            <div className="hud-heading"><span>LIVE CONTROLS</span><i /></div>
            <button onClick={remixDataset}><kbd>Q</kbd><span>Random dataset</span></button>
            <button onClick={randomizeVisual}><kbd>W</kbd><span>Visual form</span></button>
            <button onClick={randomizeHarmony}><kbd>E</kbd><span>Color harmony</span></button>
            <div className="knob-line">
              <button aria-label={`Decrease ${atmosphereTarget}`} onClick={() => turnAtmosphereKnob(-1)}><kbd>↺</kbd></button>
              <span>TURN · {atmosphereTarget}</span>
              <button aria-label={`Increase ${atmosphereTarget}`} onClick={() => turnAtmosphereKnob(1)}><kbd>↻</kbd></button>
            </div>
            <button onClick={selectNextAtmosphere}><kbd>R</kbd><span>Press · select control</span></button>
          </div>
          <div className="art-index">A—{String(seed).padStart(3, "0")}</div>
        </section>

        <aside className="panel right-panel">
          <div className="panel-heading">
            <span>03</span>
            <div><b>VISUAL LANGUAGE</b><small>Choose how the data feels</small></div>
          </div>
          <div className="mode-list">
            {MODES.map((mode) => (
              <button key={mode.id} className={visualMode === mode.id ? "active" : ""} onClick={() => setVisualMode(mode.id)}>
                <span className={`mode-icon ${mode.id}`} />
                <span><b>{mode.name}</b><small>{mode.note}</small></span>
                <i />
              </button>
            ))}
          </div>

          <div className="section-rule" />
          <div className="panel-heading compact">
            <span>04</span>
            <div><b>COLOR HARMONY</b><small>Build an emotional palette</small></div>
          </div>
          <div className="color-row">
            <label className="color-picker">
              <input type="color" value={baseColor} onChange={(event) => setBaseColor(event.target.value)} aria-label="Base color" />
              <span style={{ background: baseColor }} />
            </label>
            <div><small>BASE COLOR</small><b>{baseColor.toUpperCase()}</b></div>
          </div>
          <label className="field-label" htmlFor="harmony">Harmony</label>
          <select id="harmony" value={harmony} onChange={(event) => setHarmony(event.target.value as Harmony)}>
            <option value="analogous">Analogous — soft & cohesive</option>
            <option value="complementary">Complementary — vivid tension</option>
            <option value="split">Split-complementary — balanced contrast</option>
            <option value="triadic">Triadic — expressive balance</option>
            <option value="tetradic">Tetradic — layered & complex</option>
            <option value="square">Square — evenly vibrant</option>
            <option value="monochrome">Monochrome — tonal depth</option>
            <option value="warm">Warm spectrum — intimate & glowing</option>
            <option value="cool">Cool spectrum — calm & spacious</option>
            <option value="pastel">Pastel — soft & atmospheric</option>
            <option value="neon">Neon — electric & high energy</option>
            <option value="earth">Earth — organic & grounded</option>
            <option value="ocean">Ocean — deep & fluid</option>
          </select>
          <div className="swatches">
            {colors.map((color, index) => <span key={index} style={{ background: color }} title={color} />)}
          </div>

          <div className="section-rule" />
          <div className="panel-heading compact">
            <span>05</span>
            <div><b>ATMOSPHERE</b><small>Tune the emotional intensity</small></div>
          </div>
          {[
            { id: "density" as Atmosphere, label: "Density", value: density, setter: setDensity },
            { id: "energy" as Atmosphere, label: "Energy", value: energy, setter: setEnergy },
            { id: "flow" as Atmosphere, label: "Flow", value: flow, setter: setFlow },
          ].map(({ id, label, value, setter }) => (
            <label className={`range-control ${atmosphereTarget === id ? "knob-active" : ""}`} key={id}>
              <span><b>{label}{atmosphereTarget === id && <em>KNOB</em>}</b><small>{value}%</small></span>
              <input type="range" min="5" max="100" value={value} onFocus={() => setAtmosphereTarget(id)} onChange={(event) => setter(Number(event.target.value))} />
            </label>
          ))}
        </aside>
      </section>

      <footer>
        <span>AURA / DATA AS MATERIAL</span>
        <p>Your data stays in your browser. Nothing is uploaded.</p>
        <span>EDITION 01 · 2026</span>
      </footer>
    </main>
  );
}
